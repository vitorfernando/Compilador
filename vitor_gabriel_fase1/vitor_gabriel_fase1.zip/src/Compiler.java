/*
 Author(s): Vitor Fernando Souza Silva   RA: 552488
 Gabriel Piovani              RA: 552216 
 */

import AST.*;
import java.util.*;

public class Compiler {

    public Program compile(char[] p_input) {
        input = p_input;
        tokenPos = 0;
        nextToken();
        symbolTable = new Hashtable<Character, Variable>();
        Program result = program();
        if (token != '\0') {
            error();
        }
        return result;
    }

    //’P’ Name ’:’ Body ’E’ 
    private Program program() {
        char name = ' ';
        BodyStmt body_st = null;
        if (token == '#') {
            nextToken();
        }
        if (token == 'P') {
            nextToken();
            if (Character.isLetter(token)) {
                name = name();
                if (token == ':') {
                    nextToken();
                    body_st = body();
                    if (token == '#') {
                        nextToken();
                    }
                    if (token == 'E') {
                        nextToken();
                        return new Program(name, body_st);
                    } else {
                        error();
                    }
                }
            }
        }
        return null;
    }

    // [Declaration] Stmt {Stmt} 
    private BodyStmt body() {
        ArrayList<Stmt> stmtList = new ArrayList<Stmt>();
        ArrayList<Variable> arrayVar = null;
        if (token == '#') {
            nextToken();
        }
        if (token == 'N' || token == 'F' || token == 'S') {
            arrayVar = declaration();
        }
        if (token == '#') {
            nextToken();
        }
        Stmt st = stmt();
        if (token == '#') {
            nextToken();
        }
        if (token != 'E') {
            nextToken();
        }
        if (st != null) {
            stmtList.add(st);
            while (token == 'R' || token == 'B'
                    || token == 'I' || token == 'W'
                    || (Character.isLetter(token) && token != 'E')) {
                st = stmt();
                if (token == '#') {
                    nextToken();
                }
                if (st != null) {
                    stmtList.add(st);
                }

                if (token != 'E' && token != 'R' && token != 'B'
                        && token != 'I' && token != 'W') {
                    nextToken();
                }
            }
            return new BodyStmt(arrayVar, stmtList);
        } else {
            error();
        }
        return null;
    }

    //Type Name{’,’ Name} {’;’ Type Name{’,’ Name}} ’;’ 
    private ArrayList<Variable> declaration() {
        ArrayList<Variable> arrayVar = new ArrayList<Variable>();
        Variable var = null;
        char type = ' ';
        char name = ' ';

        if (token == 'N' || token == 'F' || token == 'S') {
            type = type();
            if (type != ' ') {
                while (token != ';') {
                    if (token == ',') {
                        nextToken();
                    }
                    name = name();
                    var = new Variable(name, type);
                    if (symbolTable.put(name, var) != null) {
                        error();
                    }
                    arrayVar.add(var);
                }
                nextToken();
                if (token == 'N' || token == 'F' || token == 'S') {
                    arrayVar.addAll(declaration());
                }
            }
        }
        return arrayVar;
    }

    //= ExprStmt | PrintStmt | BreakStmt
    private Stmt simpleStmt() {
        if (token == 'R') {
            return printStmt();
        } else if (token == 'B') {
            return breakStmt();
        } else if (Character.isLetter(token)) {
            return exprStmt();
        } else {
            error();
        }
        return null;
    }

    // SimpleStmt | CompoundStmt 
    private Stmt stmt() {
        //simpleStmt
        if (token == 'I' || token == 'W') { // compound
            return compoundStmt();
        } else if (token == 'R' || token == 'B'
                || (Character.isLetter(token) && token != 'E')) {
            return simpleStmt();
        } else {
            error();
        }
        return null;
    }

    //'’I’ Comparison ’{’ {Stmt} ’}’ [’L’ ’{’ {Stmt} ’}’]
    private Stmt iftStmt() {
        ArrayList<Stmt> stmtList1 = new ArrayList<Stmt>();
        ArrayList<Stmt> stmtList2 = new ArrayList<Stmt>();
        Stmt st1 = null, st2 = null;
        Expr e = null;
        if (token == 'I') {
            nextToken();
            e = comparison();
            if (e instanceof CompositeExpr) {
                if (token == '{') {
                    nextToken();
                    while ((token == 'R' || token == 'B')
                            || (token == 'I' || token == 'W')
                            || (Character.isLetter(token) && token != 'E')) {
                        st1 = stmt();
                        if (st1 != null) {
                            stmtList1.add(st1);
                        }
                        if (token != '}') {
                            nextToken();
                        }
                    }
                    if (token == '}') {
                        nextToken();
                    } else {
                        error();
                        return null;
                    }
                    if (token == 'L') {
                        nextToken();
                        if (token == '{') {
                            nextToken();
                            while ((token == 'R' || token == 'B')
                                    || (token == 'I' || token == 'W')) {
                                st2 = stmt();
                                if (st2 != null) {
                                    stmtList2.add(st2);
                                }
                                if (token != '}') {
                                    nextToken();
                                }
                            }
                            if (token == '}') {
                                nextToken();
                            } else {
                                error();
                                return null;
                            }
                        }
                    }
                } else {
                    error();
                    return null;
                }
            } else {
                error();
                return null;
            }
        }
        return new IfStmt(e, stmtList1, stmtList2);
    }

    // ’R’ Comparison {’,’ Comparison} 
    private Stmt printStmt() {
        ArrayList<Expr> arrayExpr = new ArrayList<Expr>();
        Expr expr;
        if (token == 'R') {
            nextToken();
            arrayExpr.add(comparison());
            while (token == ',') {
                nextToken();
                expr = comparison();
                if (expr != null) {
                    arrayExpr.add(expr);
                }
                else{
                    return null;
                }
            }
            if (token == ';') {
                nextToken();
                return new PrintStmt(arrayExpr);
            } else {
                error();
            }
        } else {
            error();
        }
        return null;
    }

    // ’B’ 
    private Stmt breakStmt() {
        if (token == 'B') {
            nextToken();
            return new BreakStmt();
        } else {
            error();
        }
        return null;
    }

    // IfStmt | WhileStmt 
    private Stmt compoundStmt() {
        if (token == 'I') {
            return iftStmt();
        } else if (token == 'W') {

            return whileStmt();
        } else {
            error();
        }
        return null;
    }

    //’W’ Comparison ’{’ {Stmt} ’}’
    private Stmt whileStmt() {
        ArrayList<Stmt> stmtList = new ArrayList<Stmt>();
        Stmt st = null;
        if (token == 'W') {
            nextToken();
            Expr e = comparison();
            if (e == null) {
                return null;
            }
            if (token == '{') {
                nextToken();
                while ((token == 'R' || token == 'B')
                        || (token == 'I' || token == 'W')
                        || (Character.isLetter(token) && token != 'E')) {
                    st = stmt();
                    if (st != null) {
                        stmtList.add(st);
                    }
                    if (token == ';') {
                        nextToken();
                    }
                }
                if (token == '}') {
                    nextToken();
                    return new WhileStmt(e, stmtList);
                } else {
                    error();
                }
            } else {
                error();
            }
        }
        return null;
    }

    // Name ’=’ Comparison 
    private Stmt exprStmt() {
        if (!Character.isLetter(token)) {
            error();
        } else {
            char name = name();
            if (token == '=') {
                nextToken();
                Expr e = comparison();
                return new ExprStmt(name, e);
            } else {
                error();
            }
        }
        return null;
    }

    // " . "’ 
    private StringExpr string() {
        String str = "";
        int max_tam = 20;
        int i = 0;
        nextToken();
        while (token != '\'') {
            str = str + token;
            nextToken2();
            i++;
            if (i > max_tam || token == ';') {
                error();
                break;
            }
        }
        nextToken();
        return new StringExpr(str);
    }

    // Expr [CompOp Expr] 
    private Expr comparison() {
        Expr e1 = expr();
        if (token == '<' || token == '>') {
            char op = compOP();
            Expr e2 = expr();
            if (e2 == null) {
                return null;
            }
            return new CompositeExpr(e1, op, e2);
        }
        return e1;
    }

    // Term {(’+’ | ’-’) Term} 
    private Expr expr() {
        char oper = ' ';
        Expr e1 = term();
        if (token == '+' || token == '-') {
            oper = token;
            nextToken();
            CompositeExpr ce = new CompositeExpr(e1, oper, expr());
            return ce;
        }
        return e1;
    }

    //Factor {(’*’ | ’/’) Factor} 
    private Expr term() {
        char oper = ' ';
        Expr e1 = factor();
        if (token == '*' || token == '/') {
            oper = token;
            nextToken();
            Expr e2 = term();
            if (e2 != null) {
                return new CompositeExpr(e1, oper, e2);
            }
            return null;
        }
        return e1;
    }

    // Name | Number | String 
    private Expr factor() {
        if (Character.isLetter(token)) {
            char ch = name();
            if (ch != '\0') {
                Variable var = symbolTable.get(ch);
                if (var != null) {
                    return new VariableExpr(var);
                } else {
                    error();
                }
            }
        } else if ((token == '+' || token == '-') || Character.isDigit(token)) {
            return number();
        } else {
            return string();
        }
        return null;
    }

    // ’N’ | ’F’ | ’S’ 
    private char type() {
        char ch = ' ';
        if (token == 'N' || token == 'F' || token == 'S') {
            ch = token;
            nextToken();
        } else {
            error();
        }
        return ch;
    }

    // ’<’ | ’>’ 
    private char compOP() {
        char op = ' ';
        if (token == '<' || token == '>') {
            op = token;
            nextToken();
        } else {
            error();
        }
        return op;
    }

    //[’+’ | ’-’] Digit [’.’ Digit] 
    private NumberExpr number() {
        char signal = '+';

        if (token == '+' || token == '-') {
            //store de signa of de number
            signal = token;
            nextToken();
        }
        if (!Character.isDigit(token)) {
            error();
        } else {
            //store the first digit of the number
            int dig1 = digit();

            if (token == '.') {
                nextToken();
                int dig2 = digit();
                return new NumberExpr(signal, dig1, dig2);
            } else {
                return new NumberExpr(signal, dig1);
            }
        }
        return null;
    }

    // ’a’ | ... | ’z’ 
    private char name() {
        if (!Character.isLetter(token)) {
            error();
            return '\0';
        } else {
            char aux = token;
            nextToken();
            return aux;
        }
    }

    //’0’ | ... | ’9’
    private int digit() {
        if (!Character.isDigit(token)) {
            error();
            return 0;
        } else {
            char aux = token;
            nextToken();
            return aux - '0';
        }
    }

    private void nextToken2() {
        if (tokenPos < input.length) {
            token = input[tokenPos];
            tokenPos++;
        } else {
            token = '\0';
        }
    }

    private void nextToken() {
        if (token == '#') {
            while ((tokenPos < input.length) && (input[tokenPos] != '\n' && input[tokenPos] != '\t')) {
                tokenPos++;
            }
        }

        while ((tokenPos < input.length) && (input[tokenPos] == ' '
                || input[tokenPos] == '\n' || input[tokenPos] == '\t')) {
            tokenPos++;
        }

        if (tokenPos < input.length) {
            token = input[tokenPos];
            tokenPos++;
        } else {
            token = '\0';
        }
    }

    private void error() {
        if (tokenPos == 0) {
            tokenPos = 1;
        } else if (tokenPos >= input.length) {
            tokenPos = input.length - 1;
        }

        String strInput = new String(input, tokenPos - 1, input.length - tokenPos + 1);
        String strError = "Error at \"" + strInput + "\"";
        System.out.print(strError);
        throw new RuntimeException(strError);
    }

    private char token;
    private int tokenPos;
    private char[] input;
    private Hashtable<Character, Variable> symbolTable;
}

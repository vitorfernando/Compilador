/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

/**
 *
 * @author vitor
 */
public class ExprStmt extends Stmt {

    private char name;
    private Expr e;

    public ExprStmt(char name, Expr e) {
        this.name = name;
        this.e = e;
    }

    public void genC(PW pw) {
        pw.out.print(name);
        pw.out.print(" = ");
        if (e instanceof StringExpr) {
            pw.out.print("'");
            e.genC(pw);
            pw.out.print("'");
        } else {
            e.genC(pw);
        }
        pw.out.println(";");
    }

}

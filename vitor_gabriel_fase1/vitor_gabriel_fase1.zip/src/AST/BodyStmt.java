/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

import java.util.ArrayList;

/**
 *
 * @author vitor
 */
public class BodyStmt extends Stmt {

    private ArrayList<Stmt> stmtList;
    private ArrayList<Variable> arrayVar;

    public BodyStmt(ArrayList<Variable> arrayVar, ArrayList<Stmt> stmtList) {
        this.stmtList = stmtList;
        this.arrayVar = arrayVar;
    }

    public boolean checkStringType() {
        if (arrayVar != null) {
            for (int i = 0; i < arrayVar.size(); i++) {
                if (arrayVar.get(i).getType() == 'S') {
                    return true;
                }
            }
        }
        return false;
    }

    public void genC(PW pw) {
        char type = ' ';
        int i = 0;
        /*while (i < (arrayVar.size())) {
            System.out.println(arrayVar.get(i).getType());
            i++;
        }*/
        i =0;
        if (arrayVar != null) {
            
            while (i < (arrayVar.size() - 1)) {
                type = arrayVar.get(i).getType();
                if (type == 'N') {
                    pw.out.print("\t");
                    pw.out.print("int ");
                } else if (type == 'F') {
                    pw.out.print("\t");
                    pw.out.print("float ");
                }
                else {
                    pw.out.print("\t");
                    pw.out.print("char ");
                }
                if (arrayVar.get(i + 1).getType() != type) {
                    pw.out.println(arrayVar.get(i).getName() + ";");
                } else {
                    pw.out.print(arrayVar.get(i).getName());
                    while (i < (arrayVar.size() - 1)) {
                        if (arrayVar.get(i + 1).getType() == type) {
                            
                            pw.out.print(",");
                            pw.out.print(arrayVar.get(i + 1).getName());
                            i++;
                        } else {
                            break;
                        }
                    }
                    pw.out.println(";");
                }

                i++;

            }
            if (i == (arrayVar.size() - 1)) {
                type = arrayVar.get(i).getType();
                if (type == 'N') {
                    pw.out.print("\t");
                    pw.out.print("int ");
                } else if (type == 'F') {
                    pw.out.print("\t");
                    pw.out.print("float ");
                }
                else {
                    pw.out.print("\t");
                    pw.out.print("char ");
                }
                pw.out.println(arrayVar.get(i).getName() + ";");
            }
            pw.out.println("");
        }

        for (Stmt st : stmtList) {
            if (st instanceof PrintStmt) {
                st.genC(pw);
            } else {
                pw.out.print("\t");
                st.genC(pw);
            }
            pw.out.print("\t");
            pw.out.println("");
        }
    }
}

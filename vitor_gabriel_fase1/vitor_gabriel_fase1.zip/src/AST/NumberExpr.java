/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

/**
 *
 * @author vitor
 */
public class NumberExpr extends Expr {

    int dig1;
    char signal;
    int dig2;
    char type;
    
    public NumberExpr(char signal, int n1) {
        this.dig1 = n1;
        this.signal = signal;
        this.dig2 = 0;
        this.type = 'N';
    }

    public NumberExpr(char signal, int n1, int n2) {
        this.dig1 = n1;
        this.signal = signal;
        this.dig2 = n2;
        this.type = 'F';
    }

    public char getType(){
        return type;
    }
    
    public void genC(PW pw) {
        if (this.signal == '-') {
            if (this.dig2 == 0) {
                pw.out.print(signal + "" + dig1);
            } else {
                pw.out.print(signal + "" + dig1 + "." + dig2);
            }
        } else {
            if (this.dig2 == 0) {
                pw.out.print(dig1);
            } else {
                pw.out.print(dig1 + "." + dig2);
            }
        }
    }
}

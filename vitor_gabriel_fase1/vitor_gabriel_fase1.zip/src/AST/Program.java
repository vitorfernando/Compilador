/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

import java.util.*;

public class Program {

    private char name;
    private BodyStmt bodyStmt;

    public Program(char name, BodyStmt body_st) {
        this.name = name;
        this.bodyStmt = body_st;
    }

    public void genC(PW pw) {
        pw.out.println("#include <stdio.h>");
        if (bodyStmt != null) {
            if (bodyStmt.checkStringType()) {
                pw.out.println("#include <string.h>");
            }
        }
        pw.out.println("\nint main(){");
        if (bodyStmt != null){
            bodyStmt.genC(pw);
        }
        pw.out.println("\treturn 0;");
        pw.out.println("}");
    }

}

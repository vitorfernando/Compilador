/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

/**
 *
 * @author vitor
 */
public class VariableExpr extends Expr { 
    private Variable var;
    
    public VariableExpr( Variable var ) { 
        this.var = var; 
    }
    
    public void genC(PW pw){
        pw.out.print(var.getName());
    }
    
    public char getType(){
        return var.getType();
    }
}

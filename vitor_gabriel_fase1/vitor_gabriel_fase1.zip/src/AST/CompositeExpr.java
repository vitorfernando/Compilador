/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

/**
 *
 * @author vitor
 */
public class CompositeExpr extends Expr { 
    public CompositeExpr( Expr pleft, char poper, Expr pright ) {
        left = pleft;
        oper = poper;
        right = pright;
    } 
    public void genC(PW pw) {
        left.genC(pw);
        pw.out.print(" " + oper + " ");
        right.genC(pw);
    } 
    private Expr left, right; 
    private char oper;    
}

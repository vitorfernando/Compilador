/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

/**
 *
 * @author vitor
 */
public class Variable {

    private char name;
    private char type;

    public char getType() {
        return type;
    }

    public char getName() {
        return name;
    }

    public Variable(char name, char type){
        this.name = name;
        this.type = type;
    }
}

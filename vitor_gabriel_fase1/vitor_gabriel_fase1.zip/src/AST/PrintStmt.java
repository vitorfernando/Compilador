/*
    Author(s): Vitor Fernando Souza Silva   RA: 552488
               Gabriel Piovani              RA: 552216 
*/
package AST;

import java.util.ArrayList;

/**
 *
 * @author vitor
 */
public class PrintStmt extends Stmt {

    private ArrayList<Expr> arrayExpr;

    public PrintStmt(ArrayList<Expr> arrayExpr) {
        this.arrayExpr = arrayExpr;
    }

    public void genC(PW pw) {
        pw.out.print("\t");
        pw.out.print("printf(\"");
        for (int i = 0; i < arrayExpr.size(); i++) {
            if (arrayExpr.get(i) instanceof StringExpr) {
                arrayExpr.get(i).genC(pw);
            } else if (arrayExpr.get(i) instanceof NumberExpr) {
                NumberExpr ne = (NumberExpr) arrayExpr.get(i);
                if (ne.getType() == 'N') {
                    pw.out.print("%d");
                }
                if (ne.getType() == 'F') {
                    pw.out.print("%f");
                }
            } else {
                VariableExpr varExpr = (VariableExpr) arrayExpr.get(i);
                char type = varExpr.getType();
                if (type == 'N') {
                    pw.out.print("%d");
                } else if (type == 'F') {
                    pw.out.print("%f");
                } else if (type == 'S') {
                    pw.out.print("%s");
                }

            }
            if ((i + 1) != arrayExpr.size()) {
                pw.out.print(" ");
            }
        }
        pw.out.print("\"");
        for (int i = 0; i < arrayExpr.size(); i++) {
            if (!(arrayExpr.get(i) instanceof StringExpr)) {
                pw.out.print(",");
                arrayExpr.get(i).genC(pw);
            }
        }
        pw.out.println(");");

    }
}
